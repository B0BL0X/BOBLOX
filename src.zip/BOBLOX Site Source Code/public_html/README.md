## HERE'S HOW TO EDIT THE SRC FOR YOUR OWN USE:
- In index.html, go to Line 29 and remove the <script> code, then go to Line 174 and edit
"<a href="/users/1/profile"><img src="/img/525c48a16d539c17460dddd939ab0276.png" width="64" border="0"></a></td>"
with your directory of your first user, can be anything. and edit the "/img/525c48a16d539c17460dddd939ab0276.png" with the path of the character's image, yes the characters are JPG or PNG.
- Edit the name "marcel" to anything and the link to any directory on Line 114
- Edit the message from Line 198 to Line 200.
- Edit the link on line 210 to your Discord link (https://discord.com/YOURUSERID).
- Edit the mailto link on Line 251.
- Now edit the "marcel" folder to anything u want [WARNING!! MUST MATCH THE PROFILE DIRECTORY THAT U WANT YOUR PROFILE TO APPEAR!]
- If you want more profiles, then clone the directory of first user and edit some files and u're good to go.
### I hope you'll like this BIO page, m5rcel is gonna be dropping a GitHub profile bio page project soon, along with modern Roblox or Telegram.